<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $pageTitle ?? "INFT2100"; ?></title>
	<!-- Link to local Bootstrap CSS -->
	<link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
		<a href="/index.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
			<img src="/dc.png" alt="Durham College Logo" style="height: 20px; margin-right: 10px;">
			<span class="fs-4">INFT2100</span>
		</a>

		<nav>
			<ul class="nav">
				<li class="nav-item"><a href="/index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a></li>
				<?php if (isset($_SESSION['user'])): ?>
					<li class="nav-item"><a href="/grades.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'grades.php' ? 'active' : ''; ?>">Dashboard</a></li>
					<li class="nav-item"><a href="/logout.php" class="nav-link">Log Out</a></li>
				<?php else: ?>
					<li class="nav-item"><a href="/login.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'active' : ''; ?>">Login</a></li>
					<li class="nav-item"><a href="/register.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'register.php' ? 'active' : ''; ?>">Register</a></li>
				<?php endif; ?>
			</ul>
		</nav>
	</header>
</div>
<main class="container">

