<?php
// Database connection details
$host = '127.0.0.1';
$port = '5433';
$db = 'ifejikaa_db';
$user = 'postgres';
$pass = 'wompwompandbighead';
$dsn = "pgsql:host=$host;port=$port;dbname=$db";
$pdo = null;

try {
	// Create a new PDO instance
	$pdo = new PDO($dsn, $user, $pass, [
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Set error mode to exception
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC // Fetch data as associative array
	]);
} catch (PDOException $e) {
	// Handle connection error
	echo "Connection failed: " . $e->getMessage();
}
