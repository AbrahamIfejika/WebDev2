<?php
/**
 * Check if user is logged in
 *
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user']);
}

/**
 * Get user by ID
 *
 * @param PDO $pdo
 * @param int $userId
 * @return array|false
 */
function getUserById($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Update user's last access time
 *
 * @param PDO $pdo
 * @param int $userId
 * @return void
 */
function updateLastAccess($pdo, $userId) {
    $stmt = $pdo->prepare("UPDATE users SET last_access = CURRENT_TIMESTAMP WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $userId]);
}

/**
 * Register a new user
 *
 * @param PDO $pdo
 * @param array $userData
 * @return int The newly created user's ID
 */
function registerUser($pdo, $userData) {
    $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, password, enrol_date, last_access) 
                           VALUES (:first_name, :last_name, :email, :password, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
    $stmt->execute([
        'first_name' => $userData['first_name'],
        'last_name' => $userData['last_name'],
        'email' => $userData['email'],
        'password' => password_hash($userData['password'], PASSWORD_BCRYPT)
    ]);
    return $pdo->lastInsertId();
}

/**
 * Register a new student
 *
 * @param PDO $pdo
 * @param array $studentData
 * @return void
 */
function registerStudent($pdo, $studentData) {
    $stmt = $pdo->prepare("INSERT INTO students (user_id, program_code) VALUES (:user_id, :program_code)");
    $stmt->execute([
        'user_id' => $studentData['user_id'],
        'program_code' => $studentData['program_code']
    ]);
}

/**
 * Authenticate a user
 *
 * @param PDO $pdo
 * @param int $userId
 * @param string $password
 * @return array|false The user data if authentication succeeds, false otherwise
 */
function authenticateUser($pdo, $userId, $password) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        return $user;
    }
    return false;
}

/**
 * Log activity to a flat file
 *
 * @param string $message
 * @return void
 */
function logActivity($message) {
    $logFile = __DIR__ . '/../logs/activity.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}
?>
