<?php
$course_code = $_GET['id'];

require_once('includes/database.php');

// Prepare and execute a query to delete a row from the users table
$stmt = $pdo->prepare("DELETE FROM courses WHERE course_code = :course_code");
$stmt->execute(['course_code' => $course_code]);

// Redirect to the index.php file
header('Location: courses-list.php');