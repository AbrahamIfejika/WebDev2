<?php
include 'includes/header.php';
include 'includes/functions.php';
include 'includes/database.php';

// Check to see if logged in
if (isLoggedIn()) {
    $_SESSION['message'] = "You are already logged in and cannot register again.";
    header("Location: grades.php");
    exit();
}

// Initialize variables
$errors = [];
$formData = [
    'first_name' => '',
    'last_name' => '',
    'email' => '',
    'password' => '',
    'confirm_password' => '',
    'program_code' => '',
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize input
    $formData['first_name'] = trim($_POST['first_name']);
    $formData['last_name'] = trim($_POST['last_name']);
    $formData['email'] = trim($_POST['email']);
    $formData['password'] = trim($_POST['password']);
    $formData['confirm_password'] = trim($_POST['confirm_password']);
    $formData['program_code'] = $_POST['program_code'] ?? '';

    // Validate input
    if (empty($formData['first_name'])) $errors['first_name'] = 'First name is required.';
    if (empty($formData['last_name'])) $errors['last_name'] = 'Last name is required.';
    if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'A valid email address is required.';
    if (strlen($formData['password']) < 8 || strlen($formData['password']) > 20) {
        $errors['password'] = 'Password must be between 8 and 20 characters.';
    }
    if ($formData['password'] !== $formData['confirm_password']) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }
    if (empty($formData['program_code'])) $errors['program_code'] = 'Please select a program.';

    // Check for duplicates
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->execute(['email' => $formData['email']]);
            if ($stmt->rowCount() > 0) {
                $errors['email'] = 'This email is already registered.';
            }
        } catch (PDOException $e) {
            die("Error checking duplicates: " . $e->getMessage());
        }
    }

    // If no errors, insert data
    if (empty($errors)) {
        try {
            $userId = registerUser($pdo, $formData);
            registerStudent($pdo, [
                'user_id' => $userId,
                'program_code' => $formData['program_code']
            ]);

            logActivity("New user registered: ID $userId, Email: {$formData['email']}");
            $_SESSION['message'] = "Registration successful! Please log in.";
            header("Location: login.php");
            exit();
        } catch (PDOException $e) {
            die("Error registering user: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Register</h1>
    <p class="text-center">Please fill out the form below to create an account.</p>

    <!-- Display Errors -->
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Registration Form -->
    <form method="POST" action="register.php">
        <div class="mb-3">
            <label for="first_name" class="form-label">First Name</label>
            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($formData['first_name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="last_name" class="form-label">Last Name</label>
            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($formData['last_name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($formData['email']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Program</label>
            <div>
                <input type="radio" id="cpga" name="program_code" value="CPGA" <?php echo ($formData['program_code'] === 'CPGA') ? 'checked' : ''; ?>>
                <label for="cpga">CPGA</label>
            </div>
            <div>
                <input type="radio" id="cppg" name="program_code" value="CPPG" <?php echo ($formData['program_code'] === 'CPPG') ? 'checked' : ''; ?>>
                <label for="cppg">CPPG</label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary w-100">Register</button>
    </form>
</div>
<script src="/js/bootstrap.bundle.min.js"></script>
</body>
</html>
