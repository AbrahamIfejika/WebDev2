<?php
    //student_id=<?= $row['student_id'] course_code=<?= $row['course_code']
$student_id = $_GET['student_id'];
$course_code = $_GET['course_code'];
require_once('includes/database.php');

// Prepare and execute a query to get a row from the marks table
$stmt = $pdo->prepare("SELECT * FROM marks WHERE student_id = :student_id AND course_code = :course_code");
$stmt->execute(['student_id' => $student_id, 'course_code' => $course_code]);
$result = $stmt->fetch();

// Get users list and create an array with the student_id as the key
$stmt = $pdo->prepare("SELECT users.first_name, users.last_name, students.student_id FROM users JOIN students ON users.user_id = students.user_id");
$stmt->execute();
$users = $stmt->fetchAll();
$users_list = [];
foreach ($users as $user) {
    $users_list[$user['student_id']] = $user;
}

// Get courses list and create an array with the course_code as the key
$stmt = $pdo->prepare("SELECT * FROM courses");
$stmt->execute();
$courses = $stmt->fetchAll();
$courses_list = [];
foreach ($courses as $course) {
    $courses_list[$course['course_code']] = $course;
}

include('layouts/header.php');
?>

<h1>Edit Final Mark</h1>

<form action="marks-update.php" method="post">
	<input type="hidden" name="original_student_id" value="<?= $result['student_id'] ?>">
    <input type="hidden" name="original_course_code" value="<?= $result['course_code'] ?>">
	<div class="form-group">
		<label for="first_name">Student</label>
		<select class="form-control" id="student_id" name="student_id">
            <?php foreach ($users_list as $student_id => $user) { ?>
                <option value="<?= $student_id ?>" <?= $student_id == $result['student_id'] ? 'selected' : '' ?>>
                    <?= $user['first_name'] . ' ' . $user['last_name'] ?>
                </option>
            <?php } ?>
        </select>
	</div>
	<div class="form-group">
		<label for="last_name">Course</label>
        <select class="form-control" id="course_code" name="course_code">
            <?php foreach ($courses_list as $course_code => $course) { ?>
                <option value="<?= $course_code ?>" <?= $course_code == $result['course_code'] ? 'selected' : '' ?>>
                    <?= $course['course_description'] ?>
                </option>
            <?php } ?>
        </select>
	</div>
	<div class="form-group">
		<label for="final_mark">Final Mark</label>
		<input type="number" min="0" max="100" class="form-control" id="final_mark" name="final_mark" value="<?= $result['final_mark'] ?>">
	</div>
	<button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php include('layouts/footer.php'); ?>
