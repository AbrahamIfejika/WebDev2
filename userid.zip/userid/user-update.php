<?php
$user_id = $_POST['user_id'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];

require_once('includes/database.php');

// Prepare and execute a query to update a row in the users table
$stmt = $pdo->prepare("UPDATE users SET first_name = :first_name, last_name = :last_name, email = :email, birth_date = :birth_date WHERE user_id = :user_id");
$stmt->execute(['first_name' => $first_name, 'last_name' => $last_name, 'email' => $email, 'user_id' => $user_id, 'birth_date' => $_POST['birth_date']]);

// Redirect to the index.php file
header('Location: index.php');
