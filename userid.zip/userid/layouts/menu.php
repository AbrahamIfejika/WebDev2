<ul class="nav nav-pills">
    <?php $cf = basename($_SERVER['PHP_SELF']); ?>
	<li class="nav-item"><a href="/user-list.php" class="nav-link<?= 'user-list.php' === $cf ? ' active' : '' ?>">Students</a></li>
	<li class="nav-item"><a href="/courses-list.php" class="nav-link<?= 'courses-list.php' === $cf ? ' active' : '' ?>">Courses</a></li>
	<li class="nav-item"><a href="/marks-list.php" class="nav-link<?= 'marks-list.php' === $cf ? ' active' : '' ?>">Marks</a></li>
</ul>