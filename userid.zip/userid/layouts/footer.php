</main>
<div class="container">
	<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
		<p class="col-md-4 mb-0 text-body-secondary">© 2024 My Name Here, Inc</p>

		<a href="/index.php" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
			<img src="/dc.png" alt="Durham College Logo" style="height: 40px;">
		</a>

		<ul class="nav col-md-4 justify-content-end">
			<li class="nav-item"><a href="/index.php" class="nav-link px-2 text-body-secondary">Home</a></li>
			<li class="nav-item"><a href="/privacy_policy.php" class="nav-link px-2 text-body-secondary">Privacy Policy</a></li>
			<li class="nav-item"><a href="/aup.php" class="nav-link px-2 text-body-secondary">Acceptable Use Policy</a></li>
			<li class="nav-item"><a href="#" class="nav-link px-2 text-body-secondary">FAQs</a></li>
			<li class="nav-item"><a href="#" class="nav-link px-2 text-body-secondary">About</a></li>
		</ul>
	</footer>
</div>

<script src="/js/bootstrap.bundle.min.js"></script>
</body>
</html>
