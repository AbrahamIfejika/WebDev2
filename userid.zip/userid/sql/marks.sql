-- Create the marks table
CREATE TABLE marks (
    student_id INT REFERENCES students(student_id) ON DELETE CASCADE,
    course_code VARCHAR(10) REFERENCES courses(course_code) ON DELETE CASCADE,
    final_mark INT CHECK (final_mark BETWEEN 0 AND 100)
);

INSERT INTO marks (student_id, course_code, final_mark)
VALUES
    (51, 'INFT 1104', 87),
    (52, 'INFT 1105', 92),
    (53, 'MATH 1114', 75),
    (54, 'COSC 1200', 88),
    (55, 'GNED 0000', 84),
    (56, 'INFT 1206', 79),
    (57, 'INFT 1207', 95),
    (58, 'MGMT 1223', 82),
    (59, 'MGMT 1224', 80),
    (60, 'COMM 2109', 91),
    (61, 'COSC 2100', 86),
    (62, 'INFT 2100', 78),
    (63, 'INFT 2101', 89),
    (64, 'MGMT 2107', 83),
    (65, 'COSC 2200', 74),
    (66, 'INFT 2200', 93),
    (67, 'INFT 2201', 70),
    (68, 'INFT 2202', 77),
    (69, 'INFT 2203', 85),
    (70, 'INFT 3100', 88),
    (71, 'INFT 3101', 69),
    (72, 'INFT 3102', 96),
    (73, 'INFT 3103', 75),
    (74, 'INFT 3104', 92),
    (75, 'CPGA 3200', 80),
    (76, 'CPGA 3201', 78),
    (77, 'INFT 3200', 86),
    (78, 'INFT 3201', 88),
    (79, 'MGMT 3211', 90);