-- Create the courses table
CREATE TABLE courses (
    course_code VARCHAR(10) PRIMARY KEY,
    course_description VARCHAR(120) NOT NULL
);

-- Populate courses table with unique courses
INSERT INTO courses (course_code, course_description)
VALUES
    ('COMM 1100', 'Communication Foundations'),
    ('COMP 1116', 'Computer Systems - Hardware'),
    ('COSC 1100', 'Introduction to Programming'),
    ('INFT 1104', 'Data Communications and Networking 1'),
    ('INFT 1105', 'Introduction to Databases'),
    ('MATH 1114', 'Mathematics for IT'),
    ('COSC 1200', 'Object-Oriented Programming 1'),
    ('GNED 0000', 'General Education Elective'),
    ('INFT 1206', 'Web Development - Fundamentals'),
    ('INFT 1207', 'Software Testing and Automation'),
    ('MGMT 1223', 'Systems Development 1'),
    ('MGMT 1224', 'Business for IT Professionals'),
    ('COMM 2109', 'IT Career Essentials'),
    ('COSC 2100', 'Object-Oriented Programming 2'),
    ('INFT 2100', 'Web Development Intermediate'),
    ('INFT 2101', 'Database Development 1'),
    ('MGMT 2107', 'Systems Development 2'),
    ('COSC 2200', 'Object-Oriented Programming 3'),
    ('INFT 2200', 'Mainframe Development 1'),
    ('INFT 2201', 'Web Development - Enterprise'),
    ('INFT 2202', 'Web Development - Client Side Script'),
    ('INFT 2203', 'Cloud Technology Fundamentals'),
    ('INFT 3100', 'Mainframe Development 2'),
    ('INFT 3101', 'Mobile Development'),
    ('INFT 3102', 'Web Development - Frameworks'),
    ('INFT 3103', 'Emerging Technologies'),
    ('INFT 3104', 'Cloud Technology for Developers'),
    ('CPGA 3200', 'Capstone Project'),
    ('CPGA 3201', 'Field Placement - CPA'),
    ('INFT 3200', 'Cloud Technology Operations'),
    ('INFT 3201', 'Database Development 2'),
    ('MGMT 3211', 'Cross-Functional Collaboration');