-- Create the users table
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    birth_date DATE,
    created_at DATE DEFAULT CURRENT_DATE,
    last_access DATE
);

-- Set the starting point for the user_id sequence
ALTER SEQUENCE users_user_id_seq RESTART WITH 100900000;

ALTER TABLE users ADD COLUMN enrol_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Populate users table with 50 sample users
INSERT INTO users (first_name, last_name, email, password, birth_date, created_at, last_access)
VALUES
    ('John', 'Doe', 'john.doe@example.com', crypt('password123', gen_salt('bf')), '1995-07-16', '2024-10-01', '2024-10-28'),
    ('Jane', 'Smith', 'jane.smith@example.com', crypt('password456', gen_salt('bf')), '1990-05-10', '2024-10-02', '2024-10-29'),
    ('Michael', 'Brown', 'michael.brown@example.com', crypt('password789', gen_salt('bf')), '1988-03-22', '2024-10-03', '2024-10-30'),
    ('Emily', 'Davis', 'emily.davis@example.com', crypt('password101', gen_salt('bf')), '1992-08-14', '2024-10-04', '2024-10-31'),
    ('David', 'Wilson', 'david.wilson@example.com', crypt('password202', gen_salt('bf')), '1993-02-18', '2024-10-05', '2024-10-29'),
    ('Jessica', 'Taylor', 'jessica.taylor@example.com', crypt('password303', gen_salt('bf')), '1994-11-09', '2024-10-06', '2024-10-28'),
    ('Chris', 'Moore', 'chris.moore@example.com', crypt('password404', gen_salt('bf')), '1987-04-23', '2024-10-07', '2024-10-27'),
    ('Sarah', 'Jackson', 'sarah.jackson@example.com', crypt('password505', gen_salt('bf')), '1991-09-01', '2024-10-08', '2024-10-26'),
    ('Brian', 'White', 'brian.white@example.com', crypt('password606', gen_salt('bf')), '1985-12-12', '2024-10-09', '2024-10-25'),
    ('Laura', 'Harris', 'laura.harris@example.com', crypt('password707', gen_salt('bf')), '1989-01-16', '2024-10-10', '2024-10-24'),
    ('Steven', 'Martin', 'steven.martin@example.com', crypt('password808', gen_salt('bf')), '1986-06-15', '2024-10-11', '2024-10-23'),
    ('Emma', 'Lee', 'emma.lee@example.com', crypt('password909', gen_salt('bf')), '1997-03-03', '2024-10-12', '2024-10-22'),
    ('Matthew', 'King', 'matthew.king@example.com', crypt('password100', gen_salt('bf')), '1994-08-08', '2024-10-13', '2024-10-21'),
    ('Olivia', 'Clark', 'olivia.clark@example.com', crypt('password111', gen_salt('bf')), '1996-12-21', '2024-10-14', '2024-10-20'),
    ('Daniel', 'Lewis', 'daniel.lewis@example.com', crypt('password121', gen_salt('bf')), '1992-07-20', '2024-10-15', '2024-10-19'),
    ('Sophia', 'Walker', 'sophia.walker@example.com', crypt('password131', gen_salt('bf')), '1993-11-02', '2024-10-16', '2024-10-18'),
    ('Jacob', 'Hall', 'jacob.hall@example.com', crypt('password141', gen_salt('bf')), '1989-10-27', '2024-10-17', '2024-10-17'),
    ('Amelia', 'Allen', 'amelia.allen@example.com', crypt('password151', gen_salt('bf')), '1998-05-15', '2024-10-18', '2024-10-16'),
    ('Ethan', 'Young', 'ethan.young@example.com', crypt('password161', gen_salt('bf')), '1991-01-25', '2024-10-19', '2024-10-15'),
    ('Isabella', 'Hernandez', 'isabella.hernandez@example.com', crypt('password171', gen_salt('bf')), '1988-06-05', '2024-10-20', '2024-10-14'),
    ('James', 'Lopez', 'james.lopez@example.com', crypt('password181', gen_salt('bf')), '1986-09-12', '2024-10-21', '2024-10-13'),
    ('Ava', 'Green', 'ava.green@example.com', crypt('password191', gen_salt('bf')), '1990-04-04', '2024-10-22', '2024-10-12'),
    ('William', 'Baker', 'william.baker@example.com', crypt('password201', gen_salt('bf')), '1987-11-16', '2024-10-23', '2024-10-11'),
    ('Mia', 'Gonzalez', 'mia.gonzalez@example.com', crypt('password211', gen_salt('bf')), '1985-12-29', '2024-10-24', '2024-10-10'),
    ('Alexander', 'Nelson', 'alexander.nelson@example.com', crypt('password221', gen_salt('bf')), '1988-07-07', '2024-10-25', '2024-10-09'),
    ('Abigail', 'Carter', 'abigail.carter@example.com', crypt('password231', gen_salt('bf')), '1994-01-09', '2024-10-26', '2024-10-08'),
    ('Mason', 'Mitchell', 'mason.mitchell@example.com', crypt('password241', gen_salt('bf')), '1993-09-17', '2024-10-27', '2024-10-07'),
    ('Charlotte', 'Perez', 'charlotte.perez@example.com', crypt('password251', gen_salt('bf')), '1992-11-23', '2024-10-28', '2024-10-06'),
    ('Logan', 'Roberts', 'logan.roberts@example.com', crypt('password261', gen_salt('bf')), '1991-05-30', '2024-10-29', '2024-10-05'),
    ('Ella', 'Turner', 'ella.turner@example.com', crypt('password271', gen_salt('bf')), '1989-02-19', '2024-10-30', '2024-10-04'),
    ('Lucas', 'Phillips', 'lucas.phillips@example.com', crypt('password281', gen_salt('bf')), '1996-04-22', '2024-10-31', '2024-10-03'),
    ('Harper', 'Campbell', 'harper.campbell@example.com', crypt('password291', gen_salt('bf')), '1990-03-13', '2024-11-01', '2024-11-02'),
    ('Benjamin', 'Parker', 'benjamin.parker@example.com', crypt('password301', gen_salt('bf')), '1987-08-18', '2024-11-02', '2024-11-03'),
    ('Lily', 'Evans', 'lily.evans@example.com', crypt('password311', gen_salt('bf')), '1988-02-15', '2024-11-03', '2024-11-04'),
    ('Henry', 'Edwards', 'henry.edwards@example.com', crypt('password321', gen_salt('bf')), '1995-09-26', '2024-11-04', '2024-11-05'),
    ('Grace', 'Collins', 'grace.collins@example.com', crypt('password331', gen_salt('bf')), '1990-12-20', '2024-11-05', '2024-11-06'),
    ('Sebastian', 'Stewart', 'sebastian.stewart@example.com', crypt('password341', gen_salt('bf')), '1989-10-10', '2024-11-06', '2024-11-07'),
    ('Zoe', 'Sanchez', 'zoe.sanchez@example.com', crypt('password351', gen_salt('bf')), '1994-08-02', '2024-11-07', '2024-11-08'),
    ('Jack', 'Morris', 'jack.morris@example.com', crypt('password361', gen_salt('bf')), '1986-05-15', '2024-11-08', '2024-11-09'),
    ('Mila', 'Rogers', 'mila.rogers@example.com', crypt('password371', gen_salt('bf')), '1993-06-18', '2024-11-09', '2024-11-10'),
    ('Owen', 'Reed', 'owen.reed@example.com', crypt('password381', gen_salt('bf')), '1992-10-05', '2024-11-10', '2024-11-11'),
    ('Ella', 'Cook', 'ella.cook@example.com', crypt('password391', gen_salt('bf')), '1991-02-23', '2024-11-11', '2024-11-12'),
    ('Daniel', 'Morgan', 'daniel.morgan@example.com', crypt('password401', gen_salt('bf')), '1990-09-14', '2024-11-12', '2024-11-13'),
    ('Avery', 'Bell', 'avery.bell@example.com', crypt('password411', gen_salt('bf')), '1987-12-25', '2024-11-13', '2024-11-14'),
    ('Jayden', 'Murphy', 'jayden.murphy@example.com', crypt('password421', gen_salt('bf')), '1988-01-12', '2024-11-14', '2024-11-15'),
    ('Aria', 'Bailey', 'aria.bailey@example.com', crypt('password431', gen_salt('bf')), '1993-03-30', '2024-11-15', '2024-11-16'),
    ('Wyatt', 'Rivera', 'wyatt.rivera@example.com', crypt('password441', gen_salt('bf')), '1985-11-19', '2024-11-16', '2024-11-17'),
    ('Scarlett', 'Sanders', 'scarlett.sanders@example.com', crypt('password451', gen_salt('bf')), '1989-07-01', '2024-11-17', '2024-11-18'),
    ('Joseph', 'Gray', 'joseph.gray@example.com', crypt('password461', gen_salt('bf')), '1991-04-25', '2024-11-18', '2024-11-19'),
    ('Riley', 'Ramirez', 'riley.ramirez@example.com', crypt('password471', gen_salt('bf')), '1992-09-08', '2024-11-19', '2024-11-20');
