<?php
$user_id = $_GET['id'];
require_once('includes/database.php');

// Prepare and execute a query to get a row from the users table
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);

// Fetch the result
$result = $stmt->fetch();

include('layouts/header.php');
?>

<h1>Edit Student</h1>

<form action="user-update.php" method="post">
	<input type="hidden" name="user_id" value="<?= $result['user_id'] ?>">
	<div class="form-group">
		<label for="first_name">First Name</label>
		<input type="text" class="form-control" id="first_name" name="first_name" value="<?= $result['first_name'] ?>">
	</div>
	<div class="form-group">
		<label for="last_name">Last Name</label>
		<input type="text" class="form-control" id="last_name" name="last_name" value="<?= $result['last_name'] ?>">
	</div>
	<div class="form-group">
		<label for="email">Email</label>
		<input type="email" class="form-control" id="email" name="email" value="<?= $result['email'] ?>">
	</div>
    <div class="form-group">
        <label for="email">Password (leave blank for no change)</label>
        <input type="email" class="form-control" id="email" name="email" value="">
    </div>
    <div class="form-group">
        <label for="email">Date of Birth</label>
        <input type="date" class="form-control" id="birth_date" name="birth_date" value="<?= $result['birth_date'] ?>">
    </div>
	<button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php include('layouts/footer.php'); ?>
