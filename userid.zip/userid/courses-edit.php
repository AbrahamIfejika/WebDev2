<?php
$course_code = $_GET['id'];
require_once('includes/database.php');

// Prepare and execute a query to get a row from the users table
$stmt = $pdo->prepare("SELECT * FROM courses WHERE course_code = :course_code");
$stmt->execute(['course_code' => $course_code]);

// Fetch the result
$result = $stmt->fetch();

include('layouts/header.php');
?>

<h1>Edit Course <?= $result['course_code'] ?></h1>

<form action="courses-update.php" method="post">
	<input type="hidden" name="course_code" value="<?= $result['course_code'] ?>">
	<div class="form-group">
		<label for="last_name">Course Name</label>
		<input type="text" class="form-control" id="course_description" name="course_description" value="<?= $result['course_description'] ?>">
	</div>
	<button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php include('layouts/footer.php'); ?>
