<?php
$student_id = $_GET['student_id'];
$course_code = $_GET['course_code'];

require_once('includes/database.php');

// Prepare and execute a query to delete a row from the users table
$stmt = $pdo->prepare("DELETE FROM marks WHERE course_code = :course_code AND student_id = :student_id");
$stmt->execute(['course_code' => $course_code, 'student_id' => $student_id]);

header('Location: marks-list.php?deleted=true');