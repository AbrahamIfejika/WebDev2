<?php
// set error reporting on
$course_code    = $_POST['course_code'];
$course_description = $_POST['course_description'];

require_once('includes/database.php');
global $pdo;

// Prepare and execute a query to update a row in the users table
$stmt = $pdo->prepare('UPDATE courses SET course_description = :course_description WHERE course_code = :course_code');
$stmt->execute(['course_code' => $course_code, 'course_description' => $course_description]);

// Redirect to the index.php file
header('Location: courses-list.php');
