<?php
$student_id = $_POST['student_id'];
$course_code = $_POST['course_code'];
$final_mark = $_POST['final_mark'];
$original_student_id = $_POST['original_student_id'];
$original_course_code = $_POST['original_course_code'];

require_once('includes/database.php');

// Prepare and execute a query to update a row in the users table
$stmt = $pdo->prepare("UPDATE marks SET student_id = :student_id, course_code = :course_code, final_mark = :final_mark WHERE course_code = :original_course_code AND student_id = :original_student_id");
$stmt->execute(['student_id' => $student_id, 'course_code' => $course_code, 'final_mark' => $final_mark, 'original_course_code' => $original_course_code, 'original_student_id' => $original_student_id]);

// Redirect to the index.php file
header('Location: marks-list.php?updated=true');
