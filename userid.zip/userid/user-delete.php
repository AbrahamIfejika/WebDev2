<?php
$user_id = $_GET['id'];

require_once('includes/database.php');

// Prepare and execute a query to delete a row from the users table
$stmt = $pdo->prepare("DELETE FROM users WHERE user_id = :user_id");
$stmt->execute(['user_id' => $user_id]);

// Redirect to the index.php file
header('Location: index.php');