<?php
include 'includes/header.php';
include 'includes/functions.php';
include 'includes/database.php';

// Check if the user is already logged in, redirect to index.php
if (isLoggedIn()) {
    header("Location: index.php");
    exit();
}

// Initialize variables
$error = '';
$loginCookie = $_COOKIE['LOGIN_COOKIE'] ?? '';
$userId = trim($loginCookie);
$password = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = trim($_POST['user_id']);
    $password = trim($_POST['password']);

    // Authenticate user
    $user = authenticateUser($pdo, $userId, $password);

    if ($user) {
        // Set session data
        $_SESSION['user'] = $user;

        // Update last access
        updateLastAccess($pdo, $user['user_id']);

        // Set login cookie
        setcookie('LOGIN_COOKIE', $userId, time() + (30 * 24 * 60 * 60), "/");

		logActivity("User logged in: ID {$user['user_id']}, Email: {$user['email']}");

        // Redirect to grades page
        header("Location: grades.php");
        exit();
    } else {
        // Log the failed login attempt
        logActivity("Failed login attempt for user ID: $userId");

        // Display error message
        $error = 'Invalid user ID or password. Please try again.';
    }
}
?>
<!doctype html>
<html lang="en" data-bs-theme="auto">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/login.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center py-4 bg-body-tertiary">
<main class="form-signin w-100 m-auto">
    <form method="POST" action="login.php">
        <img class="mb-4" src="dc.png" alt="Durham College Logo" width="72">
        <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" name="user_id" placeholder="User ID" value="<?php echo htmlspecialchars($userId); ?>" required>
            <label for="floatingInput">User ID</label>
        </div>
        <div class="form-floating">
            <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Password" required>
            <label for="floatingPassword">Password</label>
        </div>

        <div class="form-check text-start my-3">
            <input class="form-check-input" type="checkbox" value="remember-me" id="flexCheckDefault">
            <label class="form-check-label" for="flexCheckDefault">
                Remember me
            </label>
        </div>
        <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
        <p class="mt-5 mb-3 text-body-secondary">&copy; 2024</p>
    </form>
</main>
<script src="/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
