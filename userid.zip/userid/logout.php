<?php
// Start the session if not already started
session_start(); 

logActivity("User logged out: ID {$_SESSION['user']['user_id']}, Email: {$_SESSION['user']['email']}");

// Unset all session variables
session_unset();

// Destroy the session
session_destroy();

// Restart the session to show a logout message
session_start();
$_SESSION['message'] = "You have successfully logged out.";

// Redirect to login page
header("Location: ./login.php");
ob_flush();
exit();
?>

