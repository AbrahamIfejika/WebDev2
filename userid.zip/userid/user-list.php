<?php
require_once('includes/database.php');

// Prepare and execute a query to get a row from the users table
$stmt = $pdo->prepare("SELECT * FROM users ORDER BY user_id");
$stmt->execute();

// Fetch the result
$result = $stmt->fetchAll();

include('layouts/header.php');
?>
<h1>Students</h1>

<table class="table">
	<thead>
	<tr>
		<th scope="col">User ID</th>
		<th scope="col">First Name</th>
		<th scope="col">Last Name</th>
		<th scope="col">Email</th>
		<th scope="col">Actions</th>
	</tr>
	</thead>
	<tbody>
	<?php foreach ($result as $row) { ?>
	<tr>
		<th scope="row"><?= $row['user_id'] ?></th>
		<td><?= $row['first_name'] ?></td>
		<td><?= $row['last_name'] ?></td>
		<td><?= $row['email'] ?></td>
		<td>
			<a href="user-edit.php?id=<?= $row['user_id'] ?>" class="btn btn-primary">Edit</a>
			<a href="user-delete.php?id=<?= $row['user_id'] ?>" class="btn btn-danger">Delete</a>
		</td>
	</tr>
	<?php } ?>
	</tbody>
</table>

<?php include('layouts/footer.php'); ?>
