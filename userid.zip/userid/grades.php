<?php
include 'includes/header.php';
include 'includes/functions.php';
include 'includes/database.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    $_SESSION['message'] = "You must log in to access your grades.";
    header("Location: login.php");
    exit();
}

// Retrieve user data from the session
$user = $_SESSION['user'];

// Fetch grades for the logged-in user
try {
    $stmt = $pdo->prepare("
        SELECT c.course_code, c.course_name, m.final_mark 
        FROM marks m
        JOIN courses c ON m.course_code = c.course_code
        WHERE m.student_id = :student_id
    ");
    $stmt->execute(['student_id' => $user['user_id']]);
    $grades = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching grades: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Welcome, <?php echo htmlspecialchars($user['first_name']); ?>!</h1>
    <p class="text-center">Here are your grades:</p>

    <!-- Personal Information -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Personal Information</div>
        <div class="card-body">
            <p><strong>First Name:</strong> <?php echo htmlspecialchars($user['first_name']); ?></p>
            <p><strong>Last Name:</strong> <?php echo htmlspecialchars($user['last_name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Enrolment Date:</strong> <?php echo htmlspecialchars($user['enrol_date']); ?></p>
            <p><strong>Last Access:</strong> <?php echo htmlspecialchars($user['last_access']); ?></p>
        </div>
    </div>

    <!-- Grades Table -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Final Mark</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($grades)): ?>
                    <?php foreach ($grades as $grade): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($grade['course_code']); ?></td>
                            <td><?php echo htmlspecialchars($grade['course_name']); ?></td>
                            <td><?php echo htmlspecialchars($grade['final_mark']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-center">No grades available.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="/js/bootstrap.bundle.min.js"></script>
</body>
</html>
