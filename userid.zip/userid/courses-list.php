<?php
require_once('includes/database.php');

// Prepare and execute a query to get a row from the courses table
$stmt = $pdo->prepare("SELECT * FROM courses ORDER BY course_code");
$stmt->execute();

// Fetch the result
$result = $stmt->fetchAll();

include('layouts/header.php');
?>
<h1>Courses</h1>

<table class="table">
    <thead>
    <tr>
        <th scope="col">Course Code</th>
        <th scope="col">Course Name</th>
        <th scope="col">Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row) { ?>
    <tr>
        <td><?= $row['course_code'] ?></td>
        <td><?= $row['course_description'] ?></td>
        <td>
            <a href="courses-edit.php?id=<?= $row['course_code'] ?>" class="btn btn-primary">Edit</a>
            <a href="courses-delete.php?id=<?= $row['course_code'] ?>" class="btn btn-danger">Delete</a>
        </td>
    </tr>
    <?php } ?>
    </tbody>
</table>

<?php include('layouts/footer.php'); ?>
