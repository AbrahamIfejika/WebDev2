<?php 
// File: privacy_policy.php
// <!-- This Privacy Policy page was generated with the help of ChatGPT -->
include 'includes/header.php'; 
?>

<div class="container mt-5">
    <h1 class="text-center">Privacy Policy</h1>
    <p class="mt-4">
        We are committed to protecting your privacy. This privacy policy outlines how we collect, use, and protect your personal information:
    </p>
    <h2>Information We Collect</h2>
    <ul>
        <li>Personal information such as name, email address, and contact details.</li>
        <li>Login activity, including IP address and timestamps, for security purposes.</li>
        <li>Website usage data to improve user experience.</li>
    </ul>
    <h2>How We Use Your Information</h2>
    <ul>
        <li>To provide and improve our services.</li>
        <li>To contact you with updates or promotional materials (if consent is provided).</li>
        <li>To ensure security and prevent fraudulent activity.</li>
    </ul>
    <h2>Your Rights</h2>
    <ul>
        <li>You have the right to access and update your personal information.</li>
        <li>You can request the deletion of your data at any time.</li>
    </ul>
    <p>
        For detailed inquiries, please contact our support team.
    </p>
</div>

<?php include 'layouts/footer.php'; ?>
