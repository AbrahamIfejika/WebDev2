<?php
// Include header.php, which starts the session and includes the navigation bar
include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - MyApp</title>
    <!-- Include Bootstrap CSS for responsive layout and design -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Main Content Section -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12 text-center">
                <!-- Welcome Message -->
                <h1>Student Grades</h1>
                <p class="lead">Manages courses, grades, and student profiles.</p>
            </div>
        </div>

        <!-- Features Section -->
        <div class="row mt-4">
            <!-- User Login Card -->
            <div class="col-md-6 text-center">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">User Login</h5>
                        <p class="card-text">Access your personalized dashboard and manage your grades.</p>
                        <!-- Show login button if user is not logged in -->
                        <?php if (!isset($_SESSION['user'])): ?>
                            <a href="login.php" class="btn btn-primary">Login</a>
                        <?php else: ?>
                            <!-- If logged in, show dashboard button -->
                            <a href="grades.php" class="btn btn-success">Go to Dashboard</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- User Registration Card -->
            <div class="col-md-6 text-center">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Register</h5>
                        <p class="card-text">Create an account to start tracking your academic progress.</p>
                        <!-- Show register button if user is not logged in -->
                        <?php if (!isset($_SESSION['user'])): ?>
                            <a href="register.php" class="btn btn-secondary">Register</a>
                        <?php else: ?>
                            <!-- If logged in, show dashboard button -->
                            <a href="grades.php" class="btn btn-success">Go to Dashboard</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <?php 
    // Include footer.php, which contains the footer layout and links
    include 'layouts/footer.php'; 
    ?>
</body>
</html>


