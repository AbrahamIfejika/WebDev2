<?php 
// File: aup.php
// <!-- This Acceptable Use Policy page was generated with the help of ChatGPT -->
include 'includes/header.php'; 
?>

<div class="container mt-5">
    <h1 class="text-center">Acceptable Use Policy</h1>
    <p class="mt-4">
        Welcome to our website. By accessing and using this site, you agree to comply with the following acceptable use policy:
    </p>
    <ul>
        <li>You may not use the website for any illegal or unauthorized purpose.</li>
        <li>You must not attempt to gain unauthorized access to any part of the website.</li>
        <li>Any use of this site that disrupts its functionality or harms its users is strictly prohibited.</li>
        <li>You are responsible for maintaining the confidentiality of your account information.</li>
        <li>You must comply with all applicable local, state, and federal laws when using the website.</li>
    </ul>
    <p>
        For any questions regarding this policy, please contact our support team.
    </p>
</div>

<?php include 'layouts/footer.php'; ?>

