<?php
require_once('includes/database.php');

// Prepare and execute a query to get a row from the courses table
$stmt = $pdo->prepare("SELECT users.user_id, students.student_id, users.first_name, users.last_name, marks.course_code, courses.course_description, marks.final_mark
FROM users
JOIN students ON users.user_id = students.user_id
JOIN marks ON students.student_id = marks.student_id
JOIN courses ON marks.course_code = courses.course_code
ORDER BY users.user_id;");
$stmt->execute();
$result = $stmt->fetchAll();

include('layouts/header.php');
?>
<h1>Marks</h1>

<table class="table">
    <thead>
    <tr>
        <th scope="col">Student</th>
        <th scope="col">Course</th>
        <th scope="col">Mark</th>
        <th scope="col">Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row) { ?>
    <tr>
        <td><?= $row['first_name'] . ' ' . $row['last_name'] ?> (<?= $row['user_id'] ?>)</td>
        <td><?= $row['course_description'] ?> (<?= $row['course_code'] ?>)</td>
        <td><?= $row['final_mark'] ?></td>
        <td>
            <a href="marks-edit.php?student_id=<?= $row['student_id'] ?>&course_code=<?= $row['course_code'] ?>" class="btn btn-primary">Edit</a>
            <a href="marks-delete.php?student_id=<?= $row['student_id'] ?>&course_code=<?= $row['course_code'] ?>" class="btn btn-danger">Delete</a>
        </td>
    </tr>
    <?php } ?>
    </tbody>
</table>

<?php include('layouts/footer.php'); ?>
